# Vinyl Glass TV — Android TV starter

A landscape Android TV dashboard concept with:
- Vinyl-inspired album library
- Album-colour-reactive translucent panels
- Remote-friendly focus/click targets
- Now Playing layout with a lyrics panel placeholder
- Demo playback controls

## Important: Spotify phone sync is not wired up yet

This project intentionally starts in **demo mode**. The UI does not falsely claim it is connected to Spotify.

For playback on an Android phone while the TV shows the dashboard, the recommended path is the Spotify Web API:
1. Create an app in the Spotify Developer Dashboard.
2. Configure OAuth Authorization Code with PKCE for a public native client. Do not embed a client secret in the APK.
3. Request the appropriate scopes, typically `user-read-playback-state`, `user-modify-playback-state`, and `user-read-currently-playing`.
4. Retrieve the active Spotify Connect device and playback state; send play/pause/skip commands to the active phone device.
5. Spotify playback-control API availability and Premium requirements can vary by endpoint/account; check current Spotify developer policy before shipping.
6. Keep refresh tokens secure (Android Keystore-backed storage) and handle expired tokens, unavailable devices, and rate limits.

The TV and phone must use the same Spotify account for the simplest setup, and Spotify must be active/available on the phone. This app does not use the Spotify App Remote SDK directly because that SDK is intended for an app running alongside Spotify on the same Android device, not for a separate TV app controlling a phone.

## Lyrics

The lyrics pane is a placeholder. Spotify's Web API does not provide full synchronised lyrics. Use a licensed lyrics provider with a permitted API and follow its display/attribution requirements; don't scrape lyrics sites or bundle copyrighted lyrics.

## Build in Android Studio

1. Install a current Android Studio version with Android SDK 35.
2. Unzip this project.
3. Open the `VinylGlassTV` folder in Android Studio.
4. Let Gradle sync.
5. Choose an Android TV emulator or connected Android TV device.
6. Run the `app` configuration.

To build an APK from the terminal:
```bash
./gradlew assembleDebug
```
On Windows:
```bat
gradlew.bat assembleDebug
```
The debug APK should be at:
`app/build/outputs/apk/debug/app-debug.apk`

## Project structure

- `app/src/main/java/com/example/vinylglasstv/MainActivity.kt` — Compose dashboard and player UI
- `app/src/main/AndroidManifest.xml` — Android TV launcher declaration
- `app/build.gradle.kts` — Android/Compose dependencies

## Before production

This is a UI starter, not a finished production app. Add Spotify OAuth + API repository, persistence, robust D-pad focus order, loading/error states, artwork loading, a licensed lyrics provider, and test on the actual TV model. The displayed album data and clock are currently sample content.
