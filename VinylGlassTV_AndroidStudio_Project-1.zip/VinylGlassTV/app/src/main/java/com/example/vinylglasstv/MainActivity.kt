package com.example.vinylglasstv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                VinylGlassApp()
            }
        }
    }
}

private data class Album(
    val title: String,
    val artist: String,
    val year: String,
    val tint: Color,
    val trackCount: Int
)

private val albums = listOf(
    Album("SOS", "SZA", "2022", Color(0xFF3E91B8), 23),
    Album("IGOR", "Tyler, The Creator", "2019", Color(0xFFE68BB5), 12),
    Album("Ctrl", "SZA", "2017", Color(0xFF5E8B56), 14),
    Album("The Bends", "Radiohead", "1995", Color(0xFFE59A55), 12),
    Album("Blonde", "Frank Ocean", "2016", Color(0xFFB7C9D8), 17),
    Album("Discovery", "Daft Punk", "2001", Color(0xFF8D8AE8), 14)
)

private enum class Screen { HOME, PLAYER, ALBUMS }

@Composable
private fun VinylGlassApp() {
    var selectedAlbum by remember { mutableStateOf(albums.first()) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Demo mode · Connect Spotify to control your phone") }
    val scope = rememberCoroutineScope()
    val bgTint by animateColorAsState(selectedAlbum.tint.copy(alpha = 0.34f), label = "albumTint")

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color(0xFF050910))
    ) {
        // Atmospheric colour wash behind translucent glass surfaces.
        Box(
            Modifier.fillMaxSize()
                .background(Brush.radialGradient(
                    colors = listOf(bgTint, Color(0xFF101A2B), Color(0xFF050910)),
                    center = androidx.compose.ui.geometry.Offset(maxWidth.value * 0.72f, maxHeight.value * 0.30f),
                    radius = maxWidth.value * 1.15f
                ))
        )
        Row(Modifier.fillMaxSize().padding(18.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassPanel(
                modifier = Modifier.width(108.dp).fillMaxHeight(),
                tint = Color(0xFF07111B).copy(alpha = .76f)
            ) {
                Column(
                    Modifier.fillMaxSize().padding(vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    Text("◉", color = Color(0xFF42D995), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    NavItem("⌂", "Home", screen == Screen.HOME) { screen = Screen.HOME }
                    NavItem("♫", "Player", screen == Screen.PLAYER) { screen = Screen.PLAYER }
                    NavItem("▤", "Library", screen == Screen.ALBUMS) { screen = Screen.ALBUMS }
                    Spacer(Modifier.weight(1f))
                    Text("SET", color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
                }
            }

            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("8:42 PM", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Light)
                        Text("YOUR MUSIC, IN VINYL", color = Color.White.copy(alpha = .60f), fontSize = 12.sp, letterSpacing = 2.sp)
                    }
                    GlassPanel(tint = Color.White.copy(alpha = .09f)) {
                        Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                            Text("SPOTIFY CONNECTION", color = Color.White.copy(alpha = .58f), fontSize = 10.sp, letterSpacing = 1.5.sp)
                            Text(status, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                when (screen) {
                    Screen.HOME, Screen.ALBUMS -> {
                        Text(if (screen == Screen.HOME) "Your Vinyl Library  ›" else "All Albums", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                            items(albums) { album ->
                                AlbumCard(album, selectedAlbum == album, Modifier.width(190.dp).height(245.dp)) {
                                    selectedAlbum = album
                                    screen = Screen.PLAYER
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            GlassPanel(Modifier.weight(1f), tint = selectedAlbum.tint.copy(alpha = .18f)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("NOW IN THE ROOM", color = Color.White.copy(alpha = .62f), fontSize = 11.sp, letterSpacing = 1.5.sp)
                                    Text(selectedAlbum.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                                    Text(selectedAlbum.artist, color = Color.White.copy(alpha = .72f), fontSize = 15.sp)
                                    Spacer(Modifier.height(8.dp))
                                    PlaybackControls(playing, onPlay = {
                                        playing = !playing
                                        status = if (playing) "Play requested · demo mode" else "Pause requested · demo mode"
                                    }, onOpen = { screen = Screen.PLAYER })
                                }
                            }
                            GlassPanel(Modifier.width(250.dp), tint = Color.White.copy(alpha = .08f)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("QUICK ACCESS", color = Color.White.copy(alpha = .60f), fontSize = 11.sp, letterSpacing = 1.5.sp)
                                    Text("Spotify", color = Color(0xFF42D995), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("YouTube", color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
                                    Text("Settings", color = Color.White.copy(alpha = .85f), fontSize = 16.sp)
                                }
                            }
                        }
                    }
                    Screen.PLAYER -> {
                        Text("Now Playing", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            GlassPanel(Modifier.weight(1.05f).fillMaxHeight(), tint = selectedAlbum.tint.copy(alpha = .17f)) {
                                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                                        VinylDisc(selectedAlbum, Modifier.size(190.dp))
                                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(selectedAlbum.title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                            Text(selectedAlbum.artist, color = Color.White.copy(alpha = .72f), fontSize = 18.sp)
                                            Text("${selectedAlbum.year}  ·  ${selectedAlbum.trackCount} tracks", color = Color.White.copy(alpha = .50f), fontSize = 13.sp)
                                        }
                                    }
                                    Spacer(Modifier.weight(1f))
                                    PlaybackControls(playing, onPlay = {
                                        playing = !playing
                                        status = if (playing) "Play requested · demo mode" else "Pause requested · demo mode"
                                    }, onOpen = { screen = Screen.ALBUMS })
                                    Text("Spotify API connection not configured yet", color = Color.White.copy(alpha = .52f), fontSize = 12.sp)
                                }
                            }
                            GlassPanel(Modifier.weight(.78f).fillMaxHeight(), tint = selectedAlbum.tint.copy(alpha = .12f)) {
                                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("LYRICS", color = Color.White.copy(alpha = .68f), fontSize = 12.sp, letterSpacing = 2.sp)
                                    Text("Lyrics will appear here", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                                    Text("Connect a licensed lyrics provider to display timed lyrics for supported tracks.", color = Color.White.copy(alpha = .65f), fontSize = 15.sp)
                                    Spacer(Modifier.height(10.dp))
                                    listOf("Album-reactive colours", "Translucent glass panels", "Remote-friendly focus", "Synced playback (to be configured)").forEach {
                                        Text("•  $it", color = Color.White.copy(alpha = .78f), fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Column(
        Modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected || focused) Color.White.copy(alpha = .13f) else Color.Transparent)
            .border(if (focused) BorderStroke(1.dp, Color(0xFF62E6C1)) else BorderStroke(1.dp, Color.Transparent), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).onFocusChanged { focused = it.isFocused }.focusable()
            .padding(horizontal = 8.dp, vertical = 12.dp).width(84.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(icon, color = if (selected) Color(0xFF62E6C1) else Color.White.copy(alpha = .85f), fontSize = 24.sp)
        Text(label, color = Color.White.copy(alpha = .88f), fontSize = 11.sp)
    }
}

@Composable
private fun AlbumCard(album: Album, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    GlassPanel(
        modifier = modifier.onFocusChanged { focused = it.isFocused }.focusable().clickable(onClick = onClick),
        tint = album.tint.copy(alpha = if (selected || focused) .28f else .13f),
        borderColor = if (selected || focused) album.tint.copy(alpha = .9f) else Color.White.copy(alpha = .18f)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                VinylDisc(album, Modifier.size(142.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(album.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(album.artist, color = Color.White.copy(alpha = .72f), fontSize = 12.sp, maxLines = 1)
                Text(album.year, color = Color.White.copy(alpha = .50f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun VinylDisc(album: Album, modifier: Modifier = Modifier) {
    Box(modifier.clip(CircleShape).background(
        Brush.radialGradient(listOf(album.tint, album.tint.copy(alpha = .72f), Color(0xFF080B11), Color.Black))
    ), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxSize(.88f).clip(CircleShape).border(1.dp, Color.White.copy(alpha = .14f), CircleShape),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            repeat(5) { i ->
                Box(Modifier.fillMaxWidth(.90f - i * .07f).height(1.dp).background(Color.White.copy(alpha = .13f)))
                Spacer(Modifier.height(7.dp))
            }
        }
        Box(Modifier.size(48.dp).clip(CircleShape).background(album.tint.copy(alpha = .92f)), contentAlignment = Alignment.Center) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF10131B)))
        }
    }
}

@Composable
private fun PlaybackControls(playing: Boolean, onPlay: () -> Unit, onOpen: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassButton("◀◀", onClick = onOpen)
        GlassButton(if (playing) "Ⅱ" else "▶", onClick = onPlay, accent = true)
        GlassButton("▶▶", onClick = onOpen)
        Text("  ━━━━━━━━━  1:42 / 3:21", color = Color.White.copy(alpha = .60f), fontSize = 11.sp)
    }
}

@Composable
private fun GlassButton(label: String, onClick: () -> Unit, accent: Boolean = false) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(if (accent) 48.dp else 40.dp).clip(CircleShape)
            .background(if (accent) Color(0xFF42D995).copy(alpha = .92f) else Color.White.copy(alpha = .10f))
            .border(if (focused) 2.dp else 1.dp, if (focused) Color.White else Color.White.copy(alpha = .24f), CircleShape)
            .clickable(onClick = onClick).onFocusChanged { focused = it.isFocused }.focusable(),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (accent) Color(0xFF06120D) else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    tint: Color = Color.White.copy(alpha = .10f),
    borderColor: Color = Color.White.copy(alpha = .20f),
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = (tint.alpha + .08f).coerceAtMost(.55f)), Color.White.copy(alpha = .045f))))
            .border(1.dp, borderColor, RoundedCornerShape(24.dp)),
        content = content
    )
}
